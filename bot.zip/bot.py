import discord
from discord.ext import commands
from discord import ui
from discord.ui import View
import asyncio
import random
import datetime
import re

# ==========================================
# CONFIGURATION
# ==========================================
ID_SALON_ADMIN = 1536473662205599855 # Remplace par l'ID de ton salon admin
NOM_ROLE_VERIFIE = "🌎 Country Roles" # Nom du rôle donné quand le membre accepte les règles

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)


# ==========================================
# 1. RULES SYSTEM (RÈGLEMENT & VERIFICATION)
# ==========================================
class VueRules(ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Vue permanente

    @ui.button(
        label="Accept Rules", 
        style=discord.ButtonStyle.success, 
        emoji="✅", 
        custom_id="accept_rules_button"
    )
    async def accepter_regles(self, interaction: discord.Interaction, button: ui.Button):
        role_verifie = discord.utils.get(interaction.guild.roles, name=NOM_ROLE_VERIFIE)

        if not role_verifie:
            await interaction.response.send_message(
                f"❌ Error: The role **{NOM_ROLE_VERIFIE}** was not found on this server. Please inform an admin.", 
                ephemeral=True
            )
            return

        if role_verifie in interaction.user.roles:
            await interaction.response.send_message(
                "ℹ️ You have already accepted the rules and unlocked full access to the server!", 
                ephemeral=True
            )
        else:
            await interaction.user.add_roles(role_verifie)
            await interaction.response.send_message(
                f"🎉 **Welcome!** You have accepted the rules. The **{role_verifie.name}** role has been granted to you, unlocking access to all channels!", 
                ephemeral=True
            )


# ==========================================
# 2. PERMANENT GIVEAWAY SYSTEM
# ==========================================
class BoutonGiveaway(ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.participants = set()

    @ui.button(label="Enter (0)", style=discord.ButtonStyle.success, emoji="🎉", custom_id="giveaway_entry_button")
    async def participer(self, interaction: discord.Interaction, button: ui.Button):
        user_id = interaction.user.id
        
        if user_id in self.participants:
            self.participants.remove(user_id)
            button.label = f"Enter ({len(self.participants)})"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("❌ You have withdrawn your entry from the giveaway.", ephemeral=True)
        else:
            self.participants.add(user_id)
            button.label = f"Enter ({len(self.participants)})"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("🎉 Your entry has been recorded! Good luck!", ephemeral=True)

def convertir_temps(temps_str: str) -> int:
    unites = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    match = re.match(r"^(\d+)([smhd])$", temps_str.lower())
    if match:
        valeur, unite = match.groups()
        return int(valeur) * unites[unite]
    return None

@bot.command()
@commands.has_permissions(administrator=True)
async def giveaway(ctx, temps: str, *, lot: str):
    """Start a giveaway. Example: !giveaway 1m Discord Nitro"""
    await ctx.message.delete()
    
    secondes = convertir_temps(temps)
    if secondes is None or secondes <= 0:
        await ctx.send("❌ Invalid duration format! Use for example: `10s`, `5m`, `2h`, or `1d`.", delete_after=5)
        return

    fin_timestamp = int((datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=secondes)).timestamp())

    embed = discord.Embed(
        title=f"🎁 **GIVEAWAY: {lot}**",
        description=f"Click the button below to participate!\n\n⌛ **Ends:** <t:{fin_timestamp}:R> (<t:{fin_timestamp}:f>)\n👤 **Hosted by:** {ctx.author.mention}",
        color=discord.Color.gold()
    )
    embed.set_footer(text="Good luck to everyone!")

    vue = BoutonGiveaway()
    message_giveaway = await ctx.send("🎉 **NEW GIVEAWAY!** 🎉", embed=embed, view=vue)

    await asyncio.sleep(secondes)

    for child in vue.children:
        child.disabled = True

    if not vue.participants:
        embed_fin = discord.Embed(
            title=f"🎁 **GIVEAWAY ENDED: {lot}**",
            description="❌ **No winner!** Nobody entered the giveaway.",
            color=discord.Color.red()
        )
        await message_giveaway.edit(content="🔒 **GIVEAWAY ENDED**", embed=embed_fin, view=vue)
    else:
        gagnant_id = random.choice(list(vue.participants))
        gagnant = ctx.guild.get_member(gagnant_id)
        
        embed_fin = discord.Embed(
            title=f"🎁 **GIVEAWAY ENDED: {lot}**",
            description=f"🎉 **Congratulations to {gagnant.mention if gagnant else 'Winner'}!** You won **{lot}**!\n\n👥 Total participants: `{len(vue.participants)}`",
            color=discord.Color.green()
        )
        await message_giveaway.edit(content="🎊 **GIVEAWAY ENDED!**", embed=embed_fin, view=vue)
        if gagnant:
            await ctx.send(f"🥳 Congratulations {gagnant.mention}! You won **{lot}**! Open a ticket to claim your reward.")


# ==========================================
# 3. RECRUITMENT SYSTEM
# ==========================================
class FormulaireRecrutement(ui.Modal, title="Staff Application Form"):
    age = ui.TextInput(label="How old are you?", placeholder="Ex: 18 years old", min_length=1, max_length=10, required=True)
    dispos = ui.TextInput(label="What is your weekly availability?", placeholder="Ex: Every night from 6pm to 10pm...", min_length=5, max_length=100, required=True)
    motivations = ui.TextInput(label="Why should we choose you?", style=discord.TextStyle.paragraph, placeholder="Tell us about your motivations and past experience...", min_length=20, max_length=1000, required=True)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.send_message("✅ Your application has been successfully submitted to the staff! Thank you.", ephemeral=True)
        salon_admin = interaction.guild.get_channel(ID_SALON_ADMIN)
        if salon_admin:
            embed = discord.Embed(title=f"📥 New Application from {interaction.user.display_name}", color=discord.Color.blue())
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            embed.add_field(name="👤 Applicant", value=interaction.user.mention, inline=False)
            embed.add_field(name="🎂 Age", value=self.age.value, inline=True)
            embed.add_field(name="⏰ Availability", value=self.dispos.value, inline=True)
            embed.add_field(name="📝 Motivations", value=self.motivations.value, inline=False)
            embed.set_footer(text=f"User ID: {interaction.user.id}")
            await salon_admin.send(embed=embed, view=BoutonsDecision(user_id=interaction.user.id))

class BoutonsDecision(ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=None)
        self.user_id = user_id

    @ui.button(label="Accept", style=discord.ButtonStyle.success, emoji="✅", custom_id="accept_app_button")
    async def accepter(self, interaction: discord.Interaction, button: ui.Button):
        member = interaction.guild.get_member(self.user_id)
        for child in self.children:
            child.disabled = True
        embed = interaction.message.embeds[0]
        embed.color = discord.Color.green()
        embed.add_field(name="Status", value=f"✅ **Accepted by {interaction.user.mention}**", inline=False)
        await interaction.response.edit_message(embed=embed, view=self)
        if member:
            try:
                await member.send("🎉 **Congratulations!** Your staff application has been accepted!")
            except discord.Forbidden:
                pass

    @ui.button(label="Reject", style=discord.ButtonStyle.danger, emoji="❌", custom_id="reject_app_button")
    async def refuser(self, interaction: discord.Interaction, button: ui.Button):
        member = interaction.guild.get_member(self.user_id)
        for child in self.children:
            child.disabled = True
        embed = interaction.message.embeds[0]
        embed.color = discord.Color.red()
        embed.add_field(name="Status", value=f"❌ **Rejected by {interaction.user.mention}**", inline=False)
        await interaction.response.edit_message(embed=embed, view=self)
        if member:
            try:
                await member.send("Sorry, your application was not accepted at this time.")
            except discord.Forbidden:
                pass

class VueRecrutement(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="Apply", style=discord.ButtonStyle.primary, emoji="📩", custom_id="open_recruitment_modal")
    async def ouvrir_formulaire(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(FormulaireRecrutement())


# ==========================================
# 4. LANGUAGE SELECTION SYSTEM
# ==========================================
class SelectLangue(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="France", emoji="🥖", description="Access the France channel"),
            discord.SelectOption(label="Español", emoji="🌮", description="Access the Español channel"),
            discord.SelectOption(label="Português", emoji="☕", description="Access the Português channel"),
            discord.SelectOption(label="Deutsch", emoji="🍺", description="Access the Deutsch channel"),
            discord.SelectOption(label="日本語 Nihongo", emoji="🌸", description="Access the 日本語 Nihongo channel"),
            discord.SelectOption(label="русский", emoji="🪆", description="Access the русский channel"),
            discord.SelectOption(label="عربى", emoji="🕌", description="Access the عربى channel"),
            discord.SelectOption(label="中國人", emoji="🐉", description="Access the 中國人 channel"),
        ]
        super().__init__(placeholder="Choose your language...", min_values=1, max_values=1, options=options, custom_id="language_select_dropdown")

    async def callback(self, interaction: discord.Interaction):
        nom_role = self.values[0]
        role = discord.utils.get(interaction.guild.roles, name=nom_role)

        if not role:
            await interaction.response.send_message(f"❌ Error: The role **{nom_role}** was not found on this server.", ephemeral=True)
            return

        roles_langues_noms = ["France", "Español", "Português", "Deutsch", "日本語 Nihongo", "русский", "عربى", "中國人"]
        roles_a_retirer = [r for r in interaction.user.roles if r.name in roles_langues_noms and r.name != nom_role]
        
        if roles_a_retirer:
            await interaction.user.remove_roles(*roles_a_retirer)

        await interaction.user.add_roles(role)
        await interaction.response.send_message(f"✅ The **{role.name}** role has been granted to you! You can now view your channel.", ephemeral=True)

class VueLangue(ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(SelectLangue())


# ==========================================
# 5. EVENTS & COMMANDS SETUP
# ==========================================
@bot.event
async def on_ready():
    # Enregistrement des vues permanentes au démarrage du bot
    bot.add_view(VueRules())
    bot.add_view(VueRecrutement())
    bot.add_view(VueLangue())
    bot.add_view(BoutonGiveaway())
    print(f"✅ Bot online and logged in as: {bot.user.name}")

@bot.command()
@commands.has_permissions(administrator=True)
async def setup_rules(ctx):
    """Envoie l'embed joliment mis en page des règles avec le bouton d'accès."""
    await ctx.message.delete()
    
    embed = discord.Embed(
        title="📜 **SERVER RULES & COMMUNITY GUIDELINES**",
        description=(
            "Welcome to our server! To maintain a safe, friendly, and enjoyable community for everyone, "
            "please take a moment to read and follow our server guidelines.\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        ),
        color=discord.Color.blue()
    )

    embed.add_field(
        name="1️⃣ **Respect & Courtesy**",
        value="Be respectful to all members and staff. Harassment, hate speech, toxicity, discrimination, or personal attacks will not be tolerated.",
        inline=False
    )
    embed.add_field(
        name="2️⃣ **No Spam & Advertising**",
        value="Avoid spamming in text or voice channels. Unsolicited self-promotion, advertising, or sending invites in DMs is strictly prohibited.",
        inline=False
    )
    embed.add_field(
        name="3️⃣ **Appropriate Content**",
        value="Keep all discussions, profile pictures, and nicknames appropriate. NSFW, explicit, or illegal content is forbidden.",
        inline=False
    )
    embed.add_field(
        name="4️⃣ **Follow Channel Topics**",
        value="Please post content in the relevant channels. Keep discussions on-topic for each respective channel.",
        inline=False
    )
    embed.add_field(
        name="5️⃣ **Listen to Staff**",
        value="Staff members are here to help and keep the server safe. Follow their instructions at all times.",
        inline=False
    )

    embed.add_field(
        name="🔓 **UNLOCK SERVER ACCESS**",
        value="Click the **`✅ Accept Rules`** button below to agree to the rules and unlock access to all server channels!",
        inline=False
    )

    if ctx.guild.icon:
        embed.set_thumbnail(url=ctx.guild.icon.url)

    embed.set_footer(text="By clicking Accept, you agree to abide by all server rules.")

    await ctx.send(embed=embed, view=VueRules())

@bot.command()
@commands.has_permissions(administrator=True)
async def setup_recrutement(ctx):
    await ctx.message.delete()
    embed = discord.Embed(
        title="📋 Staff Recruitment",
        description="Would you like to join our server team?\n\nClick the button below to submit your application!",
        color=discord.Color.blue()
    )
    await ctx.send(embed=embed, view=VueRecrutement())

@bot.command()
@commands.has_permissions(administrator=True)
async def setup_langues(ctx):
    await ctx.message.delete()
    embed = discord.Embed(
        title="🌐 Select Your Language",
        description="Select your native language from the menu below to unlock your community channel!",
        color=discord.Color.gold()
    )
    await ctx.send(embed=embed, view=VueLangue())
#---------------------------------------------------------  
# 6 ---DONNÉES DE LA BOUTIQUE (EXTRAITES DE TES IMAGES)---
#---------------------------------------------------------

ITEMS_DATABASE = {
    "🥚 Eggs": [
        {"name": "Mystery Egg", "price": "5,99 €", "speed": "???", "type": "Special", "color": discord.Color.gold()}
    ],
    "🦜 Tropical Birds & Parrots": [
        {"name": "Common Hoopoe", "price": "2,99 €", "speed": "92 km/h", "type": "Tropical Birds", "color": discord.Color.orange()},
        {"name": "Baltimore Oriole", "price": "2,99 €", "speed": "55 km/h", "type": "Tropical Birds", "color": discord.Color.blue()},
    ],
    "🕊️ Pigeons & Doves": [
        {"name": "Pink Pigeon", "price": "9,99 €", "speed": "1500 km/h", "type": "Pigeons & Doves", "color": discord.Color.red()},
        {"name": "Common Raven", "price": "0,99 €", "speed": "48 km/h", "type": "Clever Corvids", "color": discord.Color.green()},
    ],
    "🦅 Birds of prey": [
        {"name": "White throated", "price": "0,99 €", "speed": "169 km/h", "type": "Speed Demons", "color": discord.Color.green()},
        {"name": "Common Cuckoo", "price": "FREE", "speed": "48 km/h", "type": "Cuckoos & Turacos", "color": discord.Color.dark_gray()},
    ],
    "🎵 Passerines & Songbirds": [
        {"name": "Common Myna", "price": "FREE", "speed": "32 km/h", "type": "Songbirds", "color": discord.Color.dark_purple()},
        {"name": "Superb Fairywren", "price": "2,99 €", "speed": "42 km/h", "type": "Songbirds", "color": discord.Color.blue()},
    ],
    "🐔 Poultry & Other 'Coq'": [
        {"name": "Red Junglefowl", "price": "9,99 €", "speed": "1659 km/h", "type": "Game Birds", "color": discord.Color.dark_red()},
        {"name": "Shoebill", "price": "2,99 €", "speed": "32 km/h", "type": "Cranes & Waders", "color": discord.Color.blue()},
        {"name": "Domestic Chicken", "price": "9,99 €", "speed": "1609 km/h", "type": "Games Birds", "color": discord.Color.orange()},
    ],
    "🐌 Slow & Steady": [
    {"name": "Garden Snail", "price": "FREE", "speed": "2 km/h", "type": "Slow & Steady", "color": discord.Color.green()},
    ],
    
    "🦇 Bats": [
    {"name": "Straw-colored Fruit Bat", "price": "9,99 €", "speed": "1228 km/h", "type": "Bats", "color": discord.Color.orange()},
    {"name": "Little Brown Bat", "price": "0,99 €", "speed": "35 km/h", "type": "Bats", "color": discord.Color.green()},
    ],
    "🦉 Owls": [
    {"name": "Snowy Owl", "price": "2,99 €", "speed": "80 km/h", "type": "Owls", "color": discord.Color.blue()},
    ],
    "🌊 Sea/Lake Birds": [
    {"name": "Blue-footed Booby", "price": "0,99 €", "speed": "32 km/h", "type": "Sea Birds", "color": discord.Color.green()},
    {"name": "Atlantic Puffin", "price": "0,99 €", "speed": "80 km/h", "type": "Sea Birds", "color": discord.Color.green()},
    {"name": "Grey-headed", "price": "2,99 €", "speed": "127 km/h", "type": "Albatrosses", "color": discord.Color.blue()},
    {"name": "Hawksbill Sea Turtle", "price": "2,99 €", "speed": "10 km/h", "type": "Turtle", "color": discord.Color.blue()},
    {"name": "Mata Mata", "price": "2,99 €", "speed": "1 km/h", "type": "Turtle", "color": discord.Color.blue()},
    {"name": "Eastern Box Turtle", "price": "0,99 €", "speed": "1 km/h", "type": "Turtle", "color": discord.Color.green()},
    ],
    "☄️ streak": [
    {"name": "Comet", "price": "2,99 €", "speed": "no km/h", "type": "Head of Comet", "color": discord.Color.gold()},
    ]
    }

# --- VUE INTERACTIVE DISCORD ---
class ShopView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None) # Garde le panel actif
        
    @discord.ui.select(
        placeholder="📂 Choose a bird category...",
        options=[
            discord.SelectOption(label=cat, description=f"{len(items)} article(s)")
            for cat, items in ITEMS_DATABASE.items()
        ]
    )
    async def select_category(self, interaction: discord.Interaction, select: Select):
        category = select.values[0]
        items = ITEMS_DATABASE[category]
        
        embed = discord.Embed(
            title=f"🛒 Boutique — {category}",
            description="Here are the articles available in this category:",
            color=discord.Color.blurple()
        )
        
        for item in items:
            embed.add_field(
                name=f"⚡ {item['name']} ({item['price']})",
                value=f"• **Type:** {item['type']}\n• **Vitesse:** {item['speed']}\n• **Prix:** `{item['price']}`",
                inline=False
            )
        
        embed.set_footer(text="Click Buy to order an item..")
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="🛒 BUY", style=discord.ButtonStyle.success, custom_id="buy_btn")
    async def buy_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_message(
            "💳 To finalize your purchase, open a ticket or use the command. `!buy <nom>` !", 
            ephemeral=True
        )

    @discord.ui.button(label="🔄 Refresh", style=discord.ButtonStyle.secondary, custom_id="refresh_btn")
    async def refresh_button(self, interaction: discord.Interaction, button: Button):
        embed = create_main_shop_embed()
        await interaction.response.edit_message(embed=embed, view=self)


# --- EMBED PRINCIPAL DE LA BOUTIQUE ---
def create_main_shop_embed():
    embed = discord.Embed(
        title="🦅 Shop ROOKERY IN-GAME",
        description=(
            "Welcome to the official game store !\n"
            "Unlock new birds and upgrade your fleet with extra speed.\n\n"
            "👇 **Use the menu below to filter by category !**"
        ),
        color=0xF1C40F # Jaune style bouton du jeu
    )
    
    # Aperçu des meilleures offres
    embed.add_field(name="🔥 Featured offer", value="**Red Junglefowl** — 1659 km/h (`9,99 €`)", inline=True)
    embed.add_field(name="⚡ Faster", value="**Pink Pigeon** — 1500 km/h (`9,99 €`)", inline=True)
    embed.add_field(name="🎁 Beginner Offer", value="**Garden Snail** — (`FREE`)", inline=True)
    
    embed.set_thumbnail(url="https://cdn-icons-png.flaticon.com/512/3062/3062634.png")
    embed.set_footer(text="Total items available : 23")
    return embed


# --- COMMANDE COMMANDE POUR AFFICHER LE PANEL ---
@bot.command()
@commands.has_permissions(administrator=True)
async def setup_shop(ctx):
    await ctx.message.delete()
    embed = create_main_shop_embed()
    view = ShopView()
    await ctx.send(embed=embed, view=view)

# Lancement
bot.run('MTUzNjY4NTY5MTIyNjk1MTcwMA.G8BUe0.8KDd1yutucwMFHpeL_BeTcesXA1e6w5SuHVSc0')